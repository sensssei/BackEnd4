using Microsoft.AspNetCore.Mvc;
using RoutingExample.Models;

namespace RoutingExample.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductApiController : ControllerBase
    {
        // Имитация базы данных — обычный список в памяти
        private static List<Product> _products = new List<Product>
        {
            new Product { Id = 1, Name = "Ноутбук", Price = 60000 },
            new Product { Id = 2, Name = "Смартфон", Price = 30000 }
        };

        // 🔹 Получение всех продуктов (GET api/productapi)
        [HttpGet]
        public IActionResult GetAll()
        {
            return Ok(_products);
        }

        // 🔹 Получение продукта по Id (GET api/productapi/1)
        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var product = _products.FirstOrDefault(p => p.Id == id);
            if (product == null)
                return NotFound();

            return Ok(product);
        }

       // 🔹 Добавление нового продукта (POST api/productapi)
    [HttpPost]
    public IActionResult Create([FromBody] Product product)
    {
    // Добавляем продукт в список
    _products.Add(product);

    // Возвращаем статус 201 Created с URI нового продукта
    return CreatedAtAction(nameof(GetById), new { id = product.Id }, product);
    }

        

        // 🔹 Обновление продукта (PUT api/productapi/1)
        [HttpPut("{id}")]
        public IActionResult Update(int id, Product updatedProduct)
        {
            var product = _products.FirstOrDefault(p => p.Id == id);
            if (product == null)
                return NotFound();

            product.Name = updatedProduct.Name;
            product.Price = updatedProduct.Price;

            return NoContent(); // Успех без возвращения содержимого
        }

        // 🔹 Удаление продукта (DELETE api/productapi/1)
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var product = _products.FirstOrDefault(p => p.Id == id);
            if (product == null)
                return NotFound();

            _products.Remove(product);
            return NoContent();
        }
    }
}
