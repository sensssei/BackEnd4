namespace RoutingExample.Models
{
    public class Product
    {
        public int Id { get; set; } // Идентификатор товара
        public string? Name { get; set; } // Название товара
        public decimal Price { get; set; } // Цена товара
    }
}
