using Serilog;

var builder = WebApplication.CreateBuilder(args);

// 🔹 Загрузка конфигурации
builder.Configuration
    .SetBasePath(Directory.GetCurrentDirectory())
    .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
    .AddJsonFile($"appsettings.{builder.Environment.EnvironmentName}.json", optional: true, reloadOnChange: true)
    .AddEnvironmentVariables();

// 🔹 Настройка Serilog из конфигурации
Log.Logger = new LoggerConfiguration()
    .ReadFrom.Configuration(builder.Configuration) // Здесь используется конфигурация Serilog из appsettings.json
    .CreateLogger();

builder.Host.UseSerilog(); // Используем Serilog вместо стандартного логгера

// 🔹 Добавляем сервисы MVC
builder.Services.AddControllersWithViews();
builder.Services.AddControllers();

builder.Services.AddDistributedMemoryCache(); // Используем встроенное хранилище в памяти
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30); // Время жизни сессии
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});


var app = builder.Build();

app.UseSession(); // чтобы включить middleware сессий

//  Пример использования значения из конфигурации
var mySetting = builder.Configuration["MyCustomSetting"] ?? "Default value";
Log.Information("MyCustomSetting: {Setting}", mySetting);

// Конфигурация HTTP-конвейера
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.MapControllerRoute(
    name: "products",
    pattern: "products/{action=Index}/{id?}",
    defaults: new { controller = "Products" });

app.MapControllers();

app.UseStatusCodePagesWithReExecute("/Home/StatusCode", "?code={0}");

app.Run();
