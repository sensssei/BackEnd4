using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using RoutingExample.Models;
using Microsoft.Extensions.Configuration; // Для доступа к конфигурации

namespace RoutingExample.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;
    private readonly IConfiguration _configuration;

    public HomeController(ILogger<HomeController> logger, IConfiguration configuration)
    {
        _logger = logger;
        _configuration = configuration;
    }

    public IActionResult Index()
    {
        // Получаем значение параметра из конфигурации
        var setting = _configuration["MyCustomSetting"];
        ViewBag.MySetting = setting;

        // Логируем информацию
        _logger.LogInformation("Страница Index была запрошена. Значение параметра: {Setting}", setting);

        return View();
    }

    public IActionResult Privacy()
    {
        // Пример отладочного логирования
        _logger.LogDebug("Открыта страница Privacy.");

        return View();
    }
    public IActionResult SetSession()
{
    HttpContext.Session.SetString("UserName", "Ivan");
    return Content("Сессия установлена!");
}
public IActionResult GetSession()
{
    var userName = HttpContext.Session.GetString("UserName");
    return Content($"Имя из сессии: {userName ?? "не установлено"}");
}

public IActionResult SetCookie()
{
    // Устанавливаем cookie с именем "UserName" и значением "Tom"
    CookieOptions option = new CookieOptions
    {
        Expires = DateTime.Now.AddMinutes(10) // срок действия 10 минут
    };
    Response.Cookies.Append("UserName", "Tom", option);

    ViewBag.Message = "Cookie установлено!";
    return View("Index");
}

public IActionResult GetCookie()
{
    // Читаем cookie с именем "UserName"
    var userName = Request.Cookies["UserName"];
    ViewBag.Message = $"Значение cookie: {userName}";
    return View("Index");
}


public IActionResult ClientStorage()
{
    return View();
}
[HttpGet]
public IActionResult SetNameSession()
{
    return View();
}

[HttpPost]
public IActionResult SetNameSession(string userName)
{
    HttpContext.Session.SetString("UserName", userName);
    return RedirectToAction("HelloSession");
}

public IActionResult HelloSession()
{
    var name = HttpContext.Session.GetString("UserName") ?? "Неизвестный";
    ViewBag.Name = name;
    return View();
}

public IActionResult GetHtmlResponse()
{
    // Вернем обычное представление
    return View();
}
public IActionResult GetJsonResponse()
{
    var data = new { Name = "Tom", Age = 30 }; // Пример данных
    return Json(data); // Вернем JSON
}
public IActionResult GetFileResponse()
{
    var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "files", "example.txt");
    
    if (System.IO.File.Exists(filePath))
    {
        return File(System.IO.File.ReadAllBytes(filePath), "application/octet-stream", "example.txt");
    }
    else
    {
        return NotFound("Файл не найден");
    }
}


    

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        var requestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier;

        // Логируем ошибку
        _logger.LogError("Ошибка на странице. RequestId: {RequestId}", requestId);

        return View(new ErrorViewModel { RequestId = requestId });
    }
    public new IActionResult StatusCode(int code)
{
    ViewBag.Code = code;
    return View();
}
public IActionResult Crash()
{
    throw new Exception("Тестовое исключение");
}

}
