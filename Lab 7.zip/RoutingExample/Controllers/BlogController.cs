using Microsoft.AspNetCore.Mvc;

namespace RoutingExample.Controllers
{
    [Route("blog")] // базовый маршрут для контроллера
    public class BlogController : Controller
    {
        // GET /blog
        [HttpGet("")]
        public IActionResult Index()
        {
            return Content("Добро пожаловать в блог!");
        }

        // GET /blog/{slug}
        [HttpGet("{slug}")]
        public IActionResult Article(string slug)
        {
            return Content($"Вы читаете статью: {slug}");
        }
    }
}