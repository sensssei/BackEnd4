using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using RoutingExample.Models;
using Microsoft.Extensions.Configuration; // Для доступа к конфигурации

namespace RoutingExample.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;
    private readonly IConfiguration _configuration;

    public HomeController(ILogger<HomeController> logger, IConfiguration configuration)
    {
        _logger = logger;
        _configuration = configuration;
    }

    public IActionResult Index()
    {
        // Получаем значение параметра из конфигурации
        var setting = _configuration["MyCustomSetting"];
        ViewBag.MySetting = setting;

        // Логируем информацию
        _logger.LogInformation("Страница Index была запрошена. Значение параметра: {Setting}", setting);

        return View();
    }

    public IActionResult Privacy()
    {
        // Пример отладочного логирования
        _logger.LogDebug("Открыта страница Privacy.");

        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        var requestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier;

        // Логируем ошибку
        _logger.LogError("Ошибка на странице. RequestId: {RequestId}", requestId);

        return View(new ErrorViewModel { RequestId = requestId });
    }
}
