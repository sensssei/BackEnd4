using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RoutingExample.Data;
using RoutingExample.Models;

namespace RoutingExample.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductApiController : ControllerBase
    {
        // Контекст базы данных
        private readonly AppDbContext _context;

        // Конструктор для внедрения зависимости контекста
        public ProductApiController(AppDbContext context)
        {
            _context = context;
        }

        // 🔹 Получение всех продуктов (GET api/productapi)
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var products = await _context.Products.ToListAsync();
            return Ok(products);
        }

        // 🔹 Получение продукта по Id (GET api/productapi/1)
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var product = await _context.Products.FindAsync(id);
            if (product == null)
                return NotFound();

            return Ok(product); 
        }

        // 🔹 Добавление нового продукта (POST api/productapi)
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Product product)
        {
            // Добавляем продукт в контекст
            _context.Products.Add(product);
            await _context.SaveChangesAsync();

            // Возвращаем статус 201 Created с URI нового продукта
            return CreatedAtAction(nameof(GetById), new { id = product.Id }, product);
        }

        // 🔹 Обновление продукта (PUT api/productapi/1)
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Product updatedProduct)
        {
            var product = await _context.Products.FindAsync(id);
            if (product == null)
                return NotFound();

            product.Name = updatedProduct.Name;
            product.Price = updatedProduct.Price;

            await _context.SaveChangesAsync();

            return NoContent(); // Успех без возвращения содержимого
        }

        // 🔹 Удаление продукта (DELETE api/productapi/1)
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var product = await _context.Products.FindAsync(id);
            if (product == null)
                return NotFound();

            _context.Products.Remove(product);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
