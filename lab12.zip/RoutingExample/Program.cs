using Serilog;
using RoutingExample.Data;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// 🔹 Настройка контекста базы данных
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// 🔹 Разрешение CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll",
        policy => policy.AllowAnyOrigin()
                        .AllowAnyHeader()
                        .AllowAnyMethod());
});

// 🔹 Загрузка конфигурации
builder.Configuration
    .SetBasePath(Directory.GetCurrentDirectory())
    .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
    .AddJsonFile($"appsettings.{builder.Environment.EnvironmentName}.json", optional: true, reloadOnChange: true)
    .AddEnvironmentVariables();

// 🔹 Настройка Serilog из конфигурации
Log.Logger = new LoggerConfiguration()
    .ReadFrom.Configuration(builder.Configuration) // Здесь используется конфигурация Serilog из appsettings.json
    .CreateLogger();

builder.Host.UseSerilog(); // Используем Serilog вместо стандартного логгера

// 🔹 Добавление сервисов MVC
builder.Services.AddControllersWithViews();
builder.Services.AddControllers();

// 🔹 Настройка сессий
builder.Services.AddDistributedMemoryCache(); // Используем встроенное хранилище в памяти
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30); // Время жизни сессии
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

var app = builder.Build();

// 🔹 Используем сессии в приложении
app.UseSession(); // чтобы включить middleware сессий

// Пример использования значения из конфигурации
var mySetting = builder.Configuration["MyCustomSetting"] ?? "Default value";
Log.Information("MyCustomSetting: {Setting}", mySetting);

// 🔹 Конфигурация HTTP-конвейера
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

// 🔹 Разрешение CORS
app.UseCors("AllowAll"); // Разрешаем кросс-доменные запросы

app.UseAuthorization();

// 🔹 Вывод продуктов в консоль перед запуском приложения
using (var scope = app.Services.CreateScope())
{
    var context = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    
    // Получаем все продукты из базы данных
    var products = await context.Products.ToListAsync();
    
    // Выводим продукты в консоль
    Console.WriteLine("Продукты в базе данных:");
    foreach (var product in products)
    {
        Console.WriteLine($"Id: {product.Id}, Название: {product.Name}, Цена: {product.Price}");
    }
}

// 🔹 Маршруты
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.MapControllerRoute(
    name: "products",
    pattern: "products/{action=Index}/{id?}",
    defaults: new { controller = "Products" });

app.MapControllers();

// 🔹 Обработка ошибок и статусных кодов
app.UseStatusCodePagesWithReExecute("/Home/StatusCode", "?code={0}");

app.Run();
