using Microsoft.AspNetCore.Mvc;

namespace RoutingExample.Controllers
{
    public class ProductsController : Controller
    {
        public IActionResult Index()
        {
            return Content("Список продуктов");
        }

        public IActionResult Details(int id)
        {
            return Content($"Детали продукта с ID = {id}");
        }
    }
}