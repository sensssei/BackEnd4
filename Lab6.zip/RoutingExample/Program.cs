var builder = WebApplication.CreateBuilder(args);

// 1. Добавим загрузку конфигурации из JSON-файлов и переменных среды 
builder.Configuration
    .SetBasePath(Directory.GetCurrentDirectory())
    .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
    .AddJsonFile($"appsettings.{builder.Environment.EnvironmentName}.json", optional: true, reloadOnChange: true)
    .AddEnvironmentVariables();

// 2. Доступ к конфигурации
var configuration = builder.Configuration;

// 3. Регистрируем контроллеры и представления
builder.Services.AddControllersWithViews();

var app = builder.Build();

// 4. Используем параметр из конфигурации для примера (можно использовать в любом месте ниже)
var mySetting = configuration["MyCustomSetting"] ?? "Default value";
Console.WriteLine($"MyCustomSetting: {mySetting}");

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.MapControllerRoute(
    name: "products",
    pattern: "products/{action=Index}/{id?}",
    defaults: new { controller = "Products" });

app.MapControllers();

app.Run();